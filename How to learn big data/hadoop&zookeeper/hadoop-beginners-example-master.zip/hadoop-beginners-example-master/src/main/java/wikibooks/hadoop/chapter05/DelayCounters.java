package wikibooks.hadoop.chapter05;

public enum DelayCounters {
  not_available_arrival, scheduled_arrival, early_arrival, not_available_departure,
  scheduled_departure, early_departure;
}
