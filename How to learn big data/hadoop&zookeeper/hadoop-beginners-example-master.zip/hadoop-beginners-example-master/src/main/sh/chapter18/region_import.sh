--username
<mysql user name>
--password
<mysql user password>
--connect
jdbc:mysql://<mysql host name>:<mysql port>/<database name of tpc-h>
--table
region
--split-by
r_regionkey
-m
1