--username
<mysql user name>
--password
<mysql user password>
--connect
jdbc:mysql://<mysql host name>:<mysql port>/<database name of tpc-h>
--table
supplier
--split-by
s_suppkey
-m
1